module.exports = {
  content: [
    './views/**/*.ejs', // Add path to your EJS files here
    './public/js/**/*.js', // Add any other files that use Tailwind
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
